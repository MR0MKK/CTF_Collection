﻿using System;
using System.Reflection;

[assembly: AssemblyTitle("ConfuserEx Renamer")]
[assembly: AssemblyDescription("Renaming analysis of ConfuserEx")]