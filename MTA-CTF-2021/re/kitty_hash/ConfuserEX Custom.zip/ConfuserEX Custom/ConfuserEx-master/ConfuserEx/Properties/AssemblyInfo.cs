﻿using System;
using System.Reflection;

[assembly: AssemblyTitle("ConfuserEx")]
[assembly: AssemblyDescription("ConfuserEx GUI")]