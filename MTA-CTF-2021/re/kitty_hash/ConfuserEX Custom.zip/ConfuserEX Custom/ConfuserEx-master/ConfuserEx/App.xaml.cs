﻿using System;
using System.Windows;

namespace ConfuserEx {
	public partial class App : Application { }
}