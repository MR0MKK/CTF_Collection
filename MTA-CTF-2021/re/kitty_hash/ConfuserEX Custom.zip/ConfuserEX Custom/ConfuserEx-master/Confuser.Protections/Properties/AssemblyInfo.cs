﻿using System;
using System.Reflection;

[assembly: AssemblyTitle("ConfuserEx Protections")]
[assembly: AssemblyDescription("Protections and packers of ConfuserEx")]