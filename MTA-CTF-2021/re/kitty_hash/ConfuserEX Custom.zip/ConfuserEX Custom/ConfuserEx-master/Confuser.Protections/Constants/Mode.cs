﻿using System;

namespace Confuser.Protections.Constants {
	internal enum Mode {
		Normal,
		Dynamic,
		x86
	}
}