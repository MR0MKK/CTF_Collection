﻿using System;
using System.Reflection;

[assembly: AssemblyTitle("ConfuserEx Dynamic Cipher Library")]
[assembly: AssemblyDescription("Cipher generator of ConfuserEx")]