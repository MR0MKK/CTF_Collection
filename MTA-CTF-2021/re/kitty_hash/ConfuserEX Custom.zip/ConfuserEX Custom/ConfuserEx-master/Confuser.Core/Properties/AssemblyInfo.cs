﻿using System;
using System.Reflection;

[assembly: AssemblyTitle("ConfuserEx Core")]
[assembly: AssemblyDescription("Core framework of ConfuserEx")]